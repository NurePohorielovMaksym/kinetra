import SpecialistRepository from './specialist.repository.js';

class SpecialistService {
  async getAllSpecialists() {
    return await SpecialistRepository.findAll();
  }

  async getSpecialistById(id) {
    const specialist = await SpecialistRepository.findById(id);
    if (!specialist) {
      throw new Error('Спеціаліста не знайдено');
    }
    return specialist;
  }

  async updateSpecialistProfile(id, data, requesterRole) {
  await this.getSpecialistById(id);

  const { first_name, last_name, middle_name, ...specialistFields } = data;

  const hasNameChange = first_name !== undefined || last_name !== undefined || middle_name !== undefined;
  if (hasNameChange) {
    if (requesterRole !== 'admin') {
      throw new Error('Редагувати ПІБ лікаря може лише адміністратор');
    }
    await SpecialistRepository.updateOwnerName(id, {
      first_name:  first_name?.trim()  || null,
      last_name:   last_name?.trim()   || null,
      middle_name: middle_name?.trim() || null,
    });
  }

  await SpecialistRepository.updateProfile(id, specialistFields);
  return await SpecialistRepository.findById(id);
}

async getSpecializationsList() {
  return await SpecialistRepository.getUniqueSpecializations();
}
}

export default new SpecialistService();