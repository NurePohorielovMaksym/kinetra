import TimeSlotRepository from './time-slot.repository.js';
import AppointmentRepository from '../appointments/appointment.repository.js';

class TimeSlotService {
  
  async generateStandardSchedule(specialistId) {
    const standardSlots = [];
    
    for (let day = 1; day <= 7; day++) {

      if(day === 6 || day === 7){
        standardSlots.push({
        specialist_id: specialistId,
        day_of_week: day,
        start_time: '00:00:00',
        end_time: '00:00:00',
        is_available: false
      });
      } else {
      standardSlots.push({
        specialist_id: specialistId,
        day_of_week: day,
        start_time: '10:00:00',
        end_time: '18:00:00',
        is_available: true,
        slot_duration: 60
      });
    }
  }
    return await TimeSlotRepository.createWeeklySchedule(specialistId, standardSlots);
  }

  async getSchedule(specialistId) {
    return await TimeSlotRepository.getBySpecialistId(specialistId);
  }

  async getScheduleForDate(specialistId, dateString) {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day); 
  
  let dayOfWeek = date.getDay();
  if (dayOfWeek === 0) dayOfWeek = 7;

  const slot = await TimeSlotRepository.findActiveSlot(specialistId, dateString, dayOfWeek);
  
  if (!slot) {
    throw new Error('Графік для цього спеціаліста не налаштований');
  }

  return slot;
}

async updateTemplate(specialistId, dayOfWeek, updateData) {
  const dayNum = parseInt(dayOfWeek);
  if (isNaN(dayNum) || dayNum < 1 || dayNum > 7) {
    throw new Error('Некоректний день тижня. Має бути від 1 до 7');
  }

  const currentTemplate = await TimeSlotRepository.getTemplateSlot(specialistId, dayNum);
  if (!currentTemplate) {
    throw new Error('Базовий шаблон для цього дня не знайдено');
  }

  const isAvailable = updateData.is_available !== undefined
    ? Boolean(updateData.is_available)
    : currentTemplate.is_available;

  const bookedRows = await AppointmentRepository.getBookedDatesByDayOfWeek(specialistId, dayNum);

  const toMinutes = (t) => {
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  };

  let normalized;

  if (!isAvailable) {
    if (bookedRows.length > 0) {
      throw new Error(
        "На цей день тижня вже є записи в майбутньому. Зв'яжіться з адміністратором."
      );
    }
    normalized = {
      start_time: '00:00:00',
      end_time: '00:00:00',
      is_available: false,
      slot_duration: updateData.slot_duration ?? currentTemplate.slot_duration ?? 60
    };
  } else {
    const startTime = updateData.start_time || currentTemplate.start_time;
    const endTime = updateData.end_time || currentTemplate.end_time;
    const slotDuration = updateData.slot_duration !== undefined
      ? Number(updateData.slot_duration)
      : Number(currentTemplate.slot_duration) || 60;

    if (!startTime || !endTime) {
      throw new Error('Для робочого дня треба start_time та end_time');
    }

    const startMin = toMinutes(startTime);
    const endMin = toMinutes(endTime);

    if (startMin >= endMin) {
      throw new Error('Час початку має бути раніше часу завершення');
    }
    if (!Number.isFinite(slotDuration) || slotDuration <= 0) {
      throw new Error('Тривалість прийому має бути більше нуля');
    }
    if (endMin - startMin < slotDuration) {
      throw new Error('Тривалість прийому перевищує робочий інтервал дня');
    }

    const conflict = bookedRows.find(row => {
      const tMin = toMinutes(row.appointment_time.toString().slice(0, 5));
      const insideRange = tMin >= startMin && tMin < endMin;
      const alignedToGrid = (tMin - startMin) % slotDuration === 0;
      return !insideRange || !alignedToGrid;
    });

    if (conflict) {
      const conflictDate = new Date(conflict.appointment_date).toLocaleDateString('uk-UA');
      const conflictTime = conflict.appointment_time.toString().slice(0, 5);
      throw new Error(
        `Новий графік не вписується в існуючий запис на ${conflictDate} о ${conflictTime}. Зв'яжіться з адміністратором.`
      );
    }

    normalized = {
      start_time: startTime,
      end_time: endTime,
      is_available: true,
      slot_duration: slotDuration
    };
  }

  const updatedSlot = await TimeSlotRepository.updateTemplateSlot(specialistId, dayNum, normalized);
  if (!updatedSlot) {
    throw new Error('Базовий шаблон для цього дня не знайдено');
  }

  return updatedSlot;
}

async getAvailableSlotsForPeriod(specialistId, weeksAhead = 2) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const endDate = new Date(today);
    endDate.setDate(today.getDate() + weeksAhead * 7);
    const result = [];

    for (let d = new Date(today); d <= endDate; d.setDate(d.getDate() + 1)) {
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        
        let dayOfWeek = d.getDay();
        if (dayOfWeek === 0) dayOfWeek = 7;

        const slot = await TimeSlotRepository.findActiveSlot(specialistId, dateStr, dayOfWeek);
        if (!slot || !slot.is_available) continue;

        const timeSlots = this._generateSlots(
            slot.start_time,
            slot.end_time,
            slot.slot_duration || 60
        );
        
        const booked = await AppointmentRepository.getBookedTimesBySpecialistAndDate(specialistId, dateStr);
        
        result.push({
            date: dateStr,
            dayOfWeek,
            slots: timeSlots.map((time) => {
                const appointment = booked.find(b => b.appointment_time === time);
                
                return {
                    time,
                    available: !appointment, 
                    status: appointment ? appointment.status : 'available' 
                };
            }),
        });
    }
    return result;
}

_generateSlots(startTime, endTime, durationMinutes) {
    const slots = [];
    const [sh, sm] = startTime.split(':').map(Number);
    const [eh, em] = endTime.split(':').map(Number);

    let current = sh * 60 + sm;
    const end = eh * 60 + em;

    while (current < end) {
        const h = String(Math.floor(current / 60)).padStart(2, '0');
        const m = String(current % 60).padStart(2, '0');
        slots.push(`${h}:${m}:00`);
        current += durationMinutes;
    }
    return slots;
}

async setSpecificDateException(specialistId, exceptionData) {
    if (!exceptionData.specific_date) {
        throw new Error('Необхідно вказати specific_date');
    }
    if (exceptionData.is_available === undefined) {
        throw new Error('Необхідно вказати is_available');
    }

    if (exceptionData.is_available === false) {
        const bookedTimes = await AppointmentRepository.getBookedTimesBySpecialistAndDate(
            specialistId, 
            exceptionData.specific_date
        );
        
        if (bookedTimes && bookedTimes.length > 0) {
            throw new Error("На цей день вже є записи. Зв'яжіться з адміністратором.");
        }
    }

    if (!exceptionData.is_available) {
        exceptionData.start_time = '00:00:00';
        exceptionData.end_time = '00:00:00';
    }
    
    if (
        exceptionData.is_available &&
        (
            !exceptionData.start_time ||
            !exceptionData.end_time
        )
    ) {
        throw new Error(
            'Для робочого дня треба start_time та end_time'
        );
    }
    
    if (!exceptionData.slot_duration) {
        exceptionData.slot_duration = 60;
    }
    
    return await TimeSlotRepository.upsertSpecificDate(
        specialistId,
        exceptionData
    );
}
}

export default new TimeSlotService();